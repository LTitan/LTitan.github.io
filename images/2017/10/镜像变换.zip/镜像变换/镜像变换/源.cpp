#include"Mirror.h"
int main(int argc, char **argv)
{
	Mat first = imread("Lena.jpg");
	imshow("ԭͼ", first);
	Transform a(first);
	a.showImage();
	waitKey(0);
	return 0;
}