#include "run.h"
#include "resource.h"
#define PI 3.141592648
#define num 20
void show(DWORD *pMen);
struct FIRE
{
	int r;//��ը�뾶
	int max_r;//���뾶
	int x, y;//��ը����
	int width, height;
	int cen_x, cen_y;
	int xy[240][240];//����
	bool show;
	bool draw;
	DWORD t1, t2, dt;
}fire[num];
struct  Shoot
{
	int x, y;
	int hx, hy,height;
	bool isShoot;
	DWORD t1, t2, dt;
	IMAGE img,hua;
	byte n : 1;
}shoot[num];

int main()
{
	initgraph(1000,650);//���� px
	mciSendString(L"open ./bk.mp3 alias bgm", 0, 0, 0);
	mciSendString(L"play bgm repeat", 0, 0, 0);
	welcome();
	DWORD t1 = timeGetTime();
	DWORD *pMen = GetImageBuffer();
	initFire();
	for (int i=0;i<num;i++)
	{
		bingGo(i);
	}
	BeginBatchDraw();
	while (!kbhit())
	{
		Sleep(50);
		int clr;
		for (clr = 0; clr < 900; clr++)
		{
			for (int j = 0; j < 2; j++)
			{
				int px1 = rand() % 1000;
				int py1 = rand() % 650;
				if (py1 < 649)
				{
					pMen[py1 * 1000 + px1] = pMen[py1 * 1000 + px1 + 1] = BLACK;
				}
			}
		}
		choise(t1);
		fashe();
		show(pMen);
		FlushBatchDraw();
	}
	getchar();
	return 0;
}

void welcome()
{
	settextcolor(LIGHTGREEN);
	for (int i = 0; i < 50; i++)
	{
		int x = 500 + (int)(180 * sin(PI * 2 * i / 60)),
			y = 200 + (int)(180 * cos(PI * 2 * i / 60));
		cleardevice();
		settextstyle(i, 0, L"����");
		outtextxy(x - 30, y, L"xxxxxxxxxxx");
		outtextxy(x - 10, y + 90, L"xxxxxxxxxx");
		Sleep(20);

	}
	Sleep(2000);
	cleardevice();
	IMAGE yellow, red;
	loadimage(&yellow, L"./res/h1.bmp");
	loadimage(&red, L"./res/h2.bmp");
	putimage(463, 137, &yellow);
	putimage(178, 42, &yellow);
	putimage(743, 42, &yellow);
	putimage(115, 257, &yellow);
	putimage(799, 257, &yellow);
	putimage(307, 450, &yellow);
	putimage(604, 450, &yellow);
	putimage(312, 104, &red);
	putimage(589, 104, &red);

	putimage(85, 134, &red);
	putimage(812, 134, &red);
	putimage(208, 383, &red);
	putimage(704, 383, &red);
	putimage(463, 504, &red);
	Sleep(1500);

	settextstyle(50, 0, L"΢���ź�");

	outtextxy(400, 280, L"�´�  ����!");
	outtextxy(460, 340, L"�̻�  ����!");
	Sleep(1500);
	return;
}
void initFire()
{
	//shoot.img[0]
	//shoot.img[1]
	IMAGE dan;
	WCHAR buf[128],buf2[128];
	for (int i = 0; i < num; i++) {
		IMAGE h;
		int num_dan = rand() % 4;
		int num_hua = rand() % 6;
		swprintf(buf, 128, L"./res/d%d.bmp", num_dan+1);
		swprintf(buf2, 128, L"./res/f%d.bmp", num_hua + 1);
		loadimage(&dan,buf);
		loadimage(&h,buf2);
		SetWorkingImage(&h);
		for (int a = 0; a < 240; a++)
		{
			for (int b = 0; b < 240; b++)
			{
				fire[i].xy[a][b] = getpixel(a, b);
			}
		}
		
		shoot[i].img= dan;
		//shoot[i].hua = h;
		SetWorkingImage(NULL);
	}
	//putimage(500, 300, &shoot[2].img);
}
void bingGo(int i)
{
	int rd[15] = { 130,120,123,135,158,144,142,112,110,160,157,111,126,147,120 };
	int rx[15] = { 121,130,142,140,138,118,131,137,129,150,125,144,129,135,114 };
	int ry[15] = { 111,115,146,125,118,134,132,122,119,154,151,133,120,146,130 };
	fire[i].x = 0;
	fire[i].y = 0;
	fire[i].width = fire[i].height = 240;
	fire[i].max_r = rd[i];
	fire[i].cen_x = rx[i];
	fire[i].cen_y = ry[i];
	fire[i].t1 = timeGetTime();
	fire[i].dt = 5;
	fire[i].r = 0;
	//fire[i].show = false;

	shoot[i].x = shoot[i].y = 0;
	shoot[i].hx = shoot[i].hy = 0;
	shoot[i].height = 0;
	shoot[i].t1 = timeGetTime();
	shoot[i].isShoot = false;
	shoot[i].dt = 5;
	shoot[i].n = 0;


}
void choise(DWORD &t1)
{
	DWORD t2 = timeGetTime();
	if (t2 - t1 > 100)
	{
		int m = rand() % num;
		if (m < num-1&&shoot[m].isShoot==false&&fire[m].show==false)
		{
			shoot[m].x=rand()%960;
			shoot[m].y =rand()%100+480;
			shoot[m].hx = shoot[m].x;
			shoot[m].hy = rand()%400;
			shoot[m].height = shoot[m].y-shoot[m].hy;
			shoot[m].isShoot = true;
			
			putimage(shoot[m].x, shoot[m].y, &shoot[m].img, SRCINVERT);
		}
		t1 = t2;
	}

}
void fashe()
{
	for (int i = 0; i < num; i++)
	{
		shoot[i].t2 = timeGetTime();
		if (shoot[i].t2 - shoot[i].t1 > shoot[i].dt&&shoot[i].isShoot)
		{
			putimage(shoot[i].x, shoot[i].y, &shoot[i].img, SRCINVERT);
			if (shoot[i].y > shoot[i].hy)
			{
				shoot[i].y -= 5;
			}
			
			putimage(shoot[i].x, shoot[i].y, &shoot[i].img, SRCINVERT);
			shoot[i].t1 = shoot[i].t2;
			if(shoot[i].y<=shoot[i].hy) {
				putimage(shoot[i].x, shoot[i].hy, &shoot[i].img, SRCINVERT);
				fire[i].x = shoot[i].hx+30;
				fire[i].y = shoot[i].hy+20;
				fire[i].show = true;
				fire[i].draw = true;
			}
		}
		
	}


}
void show(DWORD *pMen)
{
	int drt[16] = { 5,5,5,5,6,6,25,25,25,25,55,55,55,55,55,55 };
	for (int i=0;i<num;i++)
	{
		fire[i].t2 = timeGetTime();
		if (fire[i].t2 - fire[i].t1 > fire[i].dt&&fire[i].show == true)
		{
			if (fire[i].r < fire[i].max_r)
			{
				fire[i].r++;
				fire[i].dt = drt[fire[i].r / 10];
				fire[i].show == true;
			}
			if (fire[i].r >= fire[i].max_r - 1)
			{
				fire[i].draw = false;
				bingGo(i);
			}
			fire[i].t1 = fire[i].t2;
		}
		if (fire[i].draw == true)
		{
			for (double a = 0; a < 6.28; a+=0.01)
			{
				int x1 = (int)(fire[i].cen_x + fire[i].r*cos(a));
				int y1 = (int)(fire[i].cen_y + fire[i].r*sin(a));
				if (x1 > 0 && x1 < fire[i].width&&y1>0 && y1 < fire[i].height)
				{
					int b = fire[i].xy[x1][y1] & 0xff;
					int g = (fire[i].xy[x1][y1]>>8) & 0xff;
					int r = (fire[i].xy[x1][y1]>>16);
					int xx = (int)(fire[i].x + fire[i].r*cos(a));
					int yy = (int)(fire[i].y + fire[i].r*sin(a));
					if (r > 0x20 && g > 0x20 && b > 0x20&&xx>0&&xx<1000&&yy>0&&yy<650)
					{
						pMen[yy * 1000 + xx] = BGR(fire[i].xy[x1][y1]);
					}
				}

			}
		}
	}
}