#pragma once
#include <graphics.h>
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <mmsystem.h>
#include <time.h>
#pragma comment(lib,"winmm.lib")
using namespace std;
void welcome();
void initFire();
void bingGo(int i);
void choise(DWORD &t1);
void fashe();
